package com.example.hyrule.ui.nice

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class NiceViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is Nice Fragment"
    }
    val text: LiveData<String> = _text
}